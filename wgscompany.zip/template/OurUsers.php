<div class="single">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="single-related wow fadeInUp">
                    <h2>Our Users</h2>
                    <div class="owl-carousel related-slider">
                        <div class="post-item">
                            <div class="post-img">
                                <img src="img/client/client-1.png" />
                            </div>
                            <div class="post-text">
                                <a href="">Lorem ipsum dolor sit amet consec adipis elit</a>
                                <div class="post-meta">
                                    <p>By<a href="">Admin</a></p>
                                    <p>In<a href="">Design</a></p>
                                </div>
                            </div>
                        </div>
                        <div class="post-item">
                            <div class="post-img">
                                <img src="img/client/client-2.png" />
                            </div>
                            <div class="post-text">
                                <a href="">Lorem ipsum dolor sit amet consec adipis elit</a>
                                <div class="post-meta">
                                    <p>By<a href="">Admin</a></p>
                                    <p>In<a href="">Design</a></p>
                                </div>
                            </div>
                        </div>
                        <div class="post-item">
                            <div class="post-img">
                                <img src="img/client/client-3.png" />
                            </div>
                            <div class="post-text">
                                <a href="">Lorem ipsum dolor sit amet consec adipis elit</a>
                                <div class="post-meta">
                                    <p>By<a href="">Admin</a></p>
                                    <p>In<a href="">Design</a></p>
                                </div>
                            </div>
                        </div>
                        <div class="post-item">
                            <div class="post-img">
                                <img src="img/client/client-4.png" />
                            </div>
                            <div class="post-text">
                                <a href="">Lorem ipsum dolor sit amet consec adipis elit</a>
                                <div class="post-meta">
                                    <p>By<a href="">Admin</a></p>
                                    <p>In<a href="">Design</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>