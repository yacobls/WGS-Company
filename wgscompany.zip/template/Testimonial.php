<div class="testimonial wow fadeIn" data-wow-delay="0.1s">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="testimonial-slider-nav">
                    <div class="slider-nav"><img src="img/testimonial/testimonial-1.jpg" alt="Testimonial"></div>
                    <div class="slider-nav"><img src="img/testimonial/testimonial-2.jpg" alt="Testimonial"></div>
                    <div class="slider-nav"><img src="img/testimonial/testimonial-3.jpg" alt="Testimonial"></div>
                    <div class="slider-nav"><img src="img/testimonial/testimonial-4.jpg" alt="Testimonial"></div>
                    <div class="slider-nav"><img src="img/testimonial/testimonial-1.jpg" alt="Testimonial"></div>
                    <div class="slider-nav"><img src="img/testimonial/testimonial-2.jpg" alt="Testimonial"></div>
                    <div class="slider-nav"><img src="img/testimonial/testimonial-3.jpg" alt="Testimonial"></div>
                    <div class="slider-nav"><img src="img/testimonial/testimonial-4.jpg" alt="Testimonial"></div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="testimonial-slider">
                    <div class="slider-item">
                        <h3>Customer Name</h3>
                        <h4>profession</h4>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus nec pretium mi. Curabitur facilisis ornare velit non vulputate. Aliquam metus tortor, auctor id gravida condimentum, viverra quis sem. Curabitur non nisl nec nisi scelerisque maximus.</p>
                    </div>
                    <div class="slider-item">
                        <h3>Customer Name</h3>
                        <h4>profession</h4>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus nec pretium mi. Curabitur facilisis ornare velit non vulputate. Aliquam metus tortor, auctor id gravida condimentum, viverra quis sem. Curabitur non nisl nec nisi scelerisque maximus.</p>
                    </div>
                    <div class="slider-item">
                        <h3>Customer Name</h3>
                        <h4>profession</h4>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus nec pretium mi. Curabitur facilisis ornare velit non vulputate. Aliquam metus tortor, auctor id gravida condimentum, viverra quis sem. Curabitur non nisl nec nisi scelerisque maximus.</p>
                    </div>
                    <div class="slider-item">
                        <h3>Customer Name</h3>
                        <h4>profession</h4>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus nec pretium mi. Curabitur facilisis ornare velit non vulputate. Aliquam metus tortor, auctor id gravida condimentum, viverra quis sem. Curabitur non nisl nec nisi scelerisque maximus.</p>
                    </div>
                    <div class="slider-item">
                        <h3>Customer Name</h3>
                        <h4>profession</h4>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus nec pretium mi. Curabitur facilisis ornare velit non vulputate. Aliquam metus tortor, auctor id gravida condimentum, viverra quis sem. Curabitur non nisl nec nisi scelerisque maximus.</p>
                    </div>
                    <div class="slider-item">
                        <h3>Customer Name</h3>
                        <h4>profession</h4>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus nec pretium mi. Curabitur facilisis ornare velit non vulputate. Aliquam metus tortor, auctor id gravida condimentum, viverra quis sem. Curabitur non nisl nec nisi scelerisque maximus.</p>
                    </div>
                    <div class="slider-item">
                        <h3>Customer Name</h3>
                        <h4>profession</h4>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus nec pretium mi. Curabitur facilisis ornare velit non vulputate. Aliquam metus tortor, auctor id gravida condimentum, viverra quis sem. Curabitur non nisl nec nisi scelerisque maximus.</p>
                    </div>
                    <div class="slider-item">
                        <h3>Customer Name</h3>
                        <h4>profession</h4>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus nec pretium mi. Curabitur facilisis ornare velit non vulputate. Aliquam metus tortor, auctor id gravida condimentum, viverra quis sem. Curabitur non nisl nec nisi scelerisque maximus.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>